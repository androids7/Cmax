#include <base.h>

int init()
{
    
    return 0;
}

int event(int type, int p1, int p2)
{
    return 0;
}

int pause()
{
    return 0;
}

int resume()
{
    return 0;
}
 